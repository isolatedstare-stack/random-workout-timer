/* Random Workout Timer Stage 1 — editor. No remote services. */
(() => {
 'use strict';
 const M=window.RWTModel, $=s=>document.querySelector(s), STORAGE='rwt-v3-sessions-v1';
 const esc=s=>String(s??'').replace(/[&<>"']/g,c=>({'&':'&amp;','<':'&lt;','>':'&gt;','"':'&quot;',"'":'&#39;'}[c]));
 let store=M.emptyStore();
 try {const saved=JSON.parse(localStorage.getItem(STORAGE)||'null'); if(saved) store=M.normalizeImport(saved);} catch(e){console.error('Session load failed',e);}
 let route={screen:'home',sessionId:null,setId:null,actionId:null};
 const session=()=>store.sessions.find(s=>s.id===route.sessionId);
 const set=()=>session()?.sets.find(s=>s.id===route.setId);
 const action=()=>set()?.actions.find(a=>a.id===route.actionId);
 const issuesFor=(loc,id)=>M.validateStore(store).filter(x=>x[loc]===id);
 const issueHTML=items=>items.map(i=>`<div class="issue" role="status">${esc(i.message)}</div>`).join('');
 function toast(msg,bad=false){const n=$('#toast'); n.textContent=msg;n.className='show'+(bad?' bad':''); clearTimeout(toast.timer); toast.timer=setTimeout(()=>n.className='',4000);}
 function save(){try{localStorage.setItem(STORAGE,JSON.stringify(store));$('#saveStatus').textContent='Saved locally';return true;}catch(e){$('#saveStatus').textContent='Save failed';toast('Could not save on this device: '+e.message,true);return false;}}
 function go(screen,sessionId=null,setId=null,actionId=null){route={screen,sessionId,setId,actionId}; render();window.scrollTo(0,0);}
 function count(s){return s.sets.reduce((sum,t)=>sum+t.actions.length,0)}
 function opts(options,selected){return options.map(([v,name])=>`<option value="${esc(v)}" ${String(v)===String(selected)?'selected':''}>${esc(name)}</option>`).join('')}
 function field(label,path,val,kind='text',meta=''){
  if(kind==='select')return `<label class="field"><span>${esc(label)}</span><select data-field="${path}">${opts(meta,val)}</select></label>`;
  return `<label class="field"><span>${esc(label)}</span><input data-field="${path}" type="${kind}" value="${esc(val)}" ${kind==='number'?'inputmode="numeric" ':''}${meta}></label>`;
 }
 function nameField(label,path,val){return field(label,path,val,'text','maxlength="180" required')}
 function numberField(label,path,val,min,max){return field(label,path,val,'number',`min="${min}" max="${max}" step="1"`)}
 function statusChip(items){return `<span class="pill ${items.length?'warn':''}">${items.length?'Needs attention · '+items.length:'Ready'}</span>`}
 function actionButtons(list,index,group,id,allowDelete=true){return `<div class="actions">
 <button class="secondary icon" data-do="move-${group}" data-id="${id}" data-dir="-1" ${index===0?'disabled':''} aria-label="Move up">↑ Up</button>
 <button class="secondary icon" data-do="move-${group}" data-id="${id}" data-dir="1" ${index===list.length-1?'disabled':''} aria-label="Move down">↓ Down</button>
 <button class="secondary icon" data-do="copy-${group}" data-id="${id}">Duplicate</button>
 <button class="danger icon" data-do="delete-${group}" data-id="${id}" ${!allowDelete?'disabled title="At least one is required"':''}>Delete</button></div>`}
 function home(){return `<section class="panel"><div class="row between wrap"><div><h2>My sessions</h2><p class="muted small">${store.sessions.length} saved session${store.sessions.length===1?'':'s'}</p></div><button data-do="new-session">+ New session</button></div>
 ${store.sessions.length?store.sessions.map(s=>{const issues=issuesFor('sessionId',s.id);return `<article class="card"><div class="row between top"><div class="flex"><div class="card-title">${esc(s.name)||'<i>Unnamed session</i>'}</div><div class="card-meta">${s.sets.length} set${s.sets.length===1?'':'s'} · ${count(s)} action${count(s)===1?'':'s'}</div></div>${statusChip(issues)}</div><div class="actions"><button data-do="open-session" data-id="${s.id}">Edit session</button><button class="secondary" data-do="copy-session" data-id="${s.id}">Duplicate</button><button class="danger" data-do="delete-session" data-id="${s.id}">Delete</button></div></article>`}).join(''):'<div class="empty">No sessions yet. Create your first session to begin.</div>'}
 </section><section class="panel"><h2>Backup & sound</h2><p class="muted small">Export your sessions to JSON or import a previous backup. Importing replaces the existing sessions after confirmation.</p><div class="actions"><button class="secondary" data-do="export">Export JSON</button><button class="secondary" data-do="import">Import JSON</button><button class="ghost" data-do="test-end">Preview ending chime</button></div><p class="hint">The completion chime is included now. Automatic playback at the end of a session will be connected in Stage 2.</p></section>`}
 function sessionPage(){const s=session();if(!s)return home();const issues=issuesFor('sessionId',s.id);return `<div class="back"><button class="ghost" data-do="back">← All sessions</button></div><section class="panel"><div class="row between"><h2>Session settings</h2>${statusChip(issues)}</div>${nameField('Session name','session.name',s.name)}<p class="hint">Names must be unique across sessions.</p>${issueHTML(issues.filter(x=>!x.setId))}</section>
 <section class="panel"><div class="row between wrap"><h2>Sets <span class="tag">${s.sets.length}</span></h2><button data-do="new-set">+ Add set</button></div><p class="muted small">Sets execute in the order listed. Use Up/Down to reorder them.</p>
 ${s.sets.map((t,i)=>{const localIssues=issues.filter(x=>x.setId===t.id);return `<article class="card"><div class="row between top"><div class="flex"><div class="card-title">${i+1}. ${esc(t.name)}</div><div class="card-meta">${t.type==='reps'?'Reps-based · '+t.repetitions+' repetitions':'Time-based · '+t.duration.min+'–'+t.duration.max+'s'} · ${t.actions.length} action${t.actions.length===1?'':'s'}</div></div>${statusChip(localIssues)}</div><div class="actions"><button data-do="open-set" data-id="${t.id}">Edit set</button></div>${actionButtons(s.sets,i,'set',t.id,s.sets.length>1)}</article>`}).join('')}</section>`}
 function setPage(){const s=session(),t=set();if(!s||!t)return home();const issues=issuesFor('setId',t.id),group=t.actions.filter(a=>a.exclusive);return `<div class="back"><button class="ghost" data-do="back">← ${esc(s.name)}</button></div><section class="panel"><div class="row between"><h2>Set settings</h2>${statusChip(issues)}</div>
 ${nameField('Set name','set.name',t.name)}
 ${field('Set type','set.type',t.type,'select',[['reps','Reps-based'],['time','Time-based']])}
 ${t.type==='reps'?`<div class="grid">${numberField('Repetitions','set.repetitions',t.repetitions,1,100000)}${field('Action sequence','set.sequence',t.sequence,'select',[['standard','Standard'],['random','Random']])}</div><p class="hint">One action from the mutual-exclusion group is randomly chosen per repetition. The other actions always run.</p>`:`<div class="grid">${numberField('Set duration: min seconds','set.duration.min',t.duration.min,1,86400)}${numberField('Set duration: max seconds','set.duration.max',t.duration.max,1,86400)}</div><p class="hint">Actions are randomly repeated until the selected set duration is reached. The final action is shortened if needed.</p>`}
 ${issueHTML(issues.filter(x=>!x.actionId))}</section>
 <section class="panel"><div class="row between wrap"><h2>Actions <span class="tag">${t.actions.length}</span></h2><button data-do="new-action">+ Add action</button></div><p class="muted small">Reorder actions with Up/Down. Each has its own duration, voice instruction and metronome settings.</p>
 ${t.type==='reps'&&group.length?`<div class="exclusive"><strong>Mutual-exclusion group:</strong> ${group.length} action${group.length===1?'':'s'}, total ${group.reduce((sum,a)=>sum+a.probability,0)}%. ${group.length<2?'Add a second exclusive action.':group.reduce((sum,a)=>sum+a.probability,0)!==100?'Adjust probabilities to total 100%.':'Group is valid.'}</div>`:''}
 ${t.actions.map((a,i)=>{const localIssues=issues.filter(x=>x.actionId===a.id);return `<article class="card"><div class="row between top"><div class="flex"><div class="card-title">${i+1}. ${esc(a.name)}</div><div class="card-meta">${a.duration.min}–${a.duration.max}s${a.metronome?' · '+a.bpm+' BPM':''}${t.type==='reps'&&a.exclusive?' · Exclusive '+a.probability+'%':''}</div></div>${statusChip(localIssues)}</div><div class="actions"><button data-do="open-action" data-id="${a.id}">Edit action</button></div>${actionButtons(t.actions,i,'action',a.id,t.actions.length>1)}</article>`}).join('')}
 </section>`}
 function actionPage(){const s=session(),t=set(),a=action();if(!s||!t||!a)return home();const issues=issuesFor('actionId',a.id);return `<div class="back"><button class="ghost" data-do="back">← ${esc(t.name)}</button></div>
 <section class="panel"><div class="row between"><h2>Action settings</h2>${statusChip(issues)}</div>
 ${nameField('Action name','action.name',a.name)}
 ${field('TTS announcement','action.ttsName',a.ttsName,'text','maxlength="300"')}
 <div class="actions"><button class="ghost" data-do="restore-tts">Use action name</button><button class="secondary" data-do="test-tts">Test announcement</button></div>
 <p class="hint">The announcement initially follows the action name. Edit it to use a different spoken instruction.</p>
 <div class="grid">${numberField('Duration: min seconds','action.duration.min',a.duration.min,1,86400)}${numberField('Duration: max seconds','action.duration.max',a.duration.max,1,86400)}</div>
 ${t.type==='reps'?`<div class="exclusive"><label class="toggle"><input type="checkbox" data-field="action.exclusive" ${a.exclusive?'checked':''}><strong>Mutually exclusive</strong></label><p class="hint">When selected, this action belongs to the set's single weighted-selection group.</p>${a.exclusive?numberField('Selection probability (%)','action.probability',a.probability,0,100):''}</div>`:`<p class="hint">Mutual exclusion is available only in reps-based sets.</p>`}
 <div class="exclusive"><label class="toggle"><input type="checkbox" data-field="action.metronome" ${a.metronome?'checked':''}><strong>Enable metronome</strong></label>${a.metronome?numberField('Metronome BPM','action.bpm',a.bpm,20,300):''}<p class="hint">Metronome playback and audio ducking will be connected in Stage 3.</p></div>
 ${issueHTML(issues)}</section>`}
 function render(){let page=route.screen==='home'?home():route.screen==='session'?sessionPage():route.screen==='set'?setPage():actionPage();$('#app').innerHTML=page;$('#saveStatus').textContent='Saved locally';}
 function valueTarget(path){const [entity,...fields]=path.split('.');const obj=entity==='session'?session():entity==='set'?set():action();if(!obj)return null;let parent=obj;for(let i=0;i<fields.length-1;i++)parent=parent[fields[i]];return {obj,parent,key:fields[fields.length-1],field:fields.join('.')};}
 function onField(el){const path=el.dataset.field;if(!path)return;const target=valueTarget(path);if(!target)return;
 const {obj,parent,key,field}=target;let val=el.type==='checkbox'?el.checked:el.type==='number'?(el.value.trim()===''?null:Number(el.value)):el.value;
 if(field==='name' && typeof val==='string' && !obj.ttsCustomized && obj.ttsName===obj.name) obj.ttsName=val;
 parent[key]=val;
 if(field==='ttsName')obj.ttsCustomized=val!==obj.name;
 if(field==='type' && val==='time'){} // Keep reps settings for when users switch types again.
 save();
 }
 function onButton(node){const cmd=node.dataset.do,id=node.dataset.id,dir=Number(node.dataset.dir);
 if(cmd==='back'){if(route.screen==='action')go('set',route.sessionId,route.setId);else if(route.screen==='set')go('session',route.sessionId);else go('home');return;}
 if(cmd==='new-session'){const s=M.newSession(M.uniqueName('Session 1',store.sessions));store.sessions.push(s);save();go('session',s.id);return;}
 if(cmd==='new-set'){const s=session();if(!s)return;const t=M.newSet(M.uniqueName('Set '+(s.sets.length+1),s.sets));s.sets.push(t);save();go('set',s.id,t.id);return;}
 if(cmd==='new-action'){const t=set();if(!t)return;const a=M.newAction('Action '+(t.actions.length+1));t.actions.push(a);save();go('action',route.sessionId,t.id,a.id);return;}
 if(cmd==='open-session'){go('session',id);return;}
 if(cmd==='open-set'){go('set',route.sessionId,id);return;}
 if(cmd==='open-action'){go('action',route.sessionId,route.setId,id);return;}
 if(cmd==='copy-session'){const i=store.sessions.findIndex(s=>s.id===id);if(i<0)return;const copy=M.copySession(store.sessions[i],store.sessions);store.sessions.splice(i+1,0,copy);save();render();toast('Session duplicated.');return;}
 if(cmd==='copy-set'){const s=session(),i=s.sets.findIndex(t=>t.id===id);if(i<0)return;const copy=M.copySet(s.sets[i],s.sets);s.sets.splice(i+1,0,copy);save();render();toast('Set duplicated.');return;}
 if(cmd==='copy-action'){const t=set(),i=t.actions.findIndex(a=>a.id===id);if(i<0)return;const copy=M.copyAction(t.actions[i]);t.actions.splice(i+1,0,copy);save();render();toast('Action duplicated.');return;}
 if(cmd==='delete-session'){const s=store.sessions.find(x=>x.id===id);if(!s||!confirm('Delete "'+s.name+'" and ALL its sets and actions? This cannot be undone.'))return;store.sessions=store.sessions.filter(x=>x.id!==id);save();render();toast('Session deleted.');return;}
 if(cmd==='delete-set'){const s=session(),t=s.sets.find(x=>x.id===id);if(!t)return;if(s.sets.length<=1){toast('Every session must have at least one set.',true);return;}if(!confirm('Delete set "'+t.name+'" and all its actions?'))return;s.sets=s.sets.filter(x=>x.id!==id);save();render();toast('Set deleted.');return;}
 if(cmd==='delete-action'){const t=set(),a=t.actions.find(x=>x.id===id);if(!a)return;if(t.actions.length<=1){toast('Every set must have at least one action.',true);return;}if(!confirm('Delete action "'+a.name+'"?'))return;t.actions=t.actions.filter(x=>x.id!==id);save();render();toast('Action deleted.');return;}
 if(cmd?.startsWith('move-')){const group=cmd.slice(5),list=group==='set'?session()?.sets:set()?.actions;const i=list?.findIndex(x=>x.id===id);if(i===undefined||i<0)return;M.move(list,i,dir);save();render();return;}
 if(cmd==='restore-tts'){const a=action();if(a){a.ttsName=a.name;a.ttsCustomized=false;save();render();toast('Announcement now follows the action name.')}return;}
 if(cmd==='test-tts'){const a=action();if(!a?.ttsName.trim())return toast('Enter an announcement first.',true);if(window.AndroidSpeech){AndroidSpeech.speak(a.ttsName,'system');toast('Sending announcement to Android TTS.')}else if(window.speechSynthesis){speechSynthesis.cancel();speechSynthesis.speak(new SpeechSynthesisUtterance(a.ttsName));}else toast('Speech preview is available in Android.',true);return;}
 if(cmd==='test-end'){if(window.AndroidSpeech&&typeof AndroidSpeech.playCompletionSound==='function'){AndroidSpeech.playCompletionSound();toast('Playing end-of-session chime.');}else{new Audio('session_end_bong.ogg').play().then(()=>toast('Playing end-of-session chime.')).catch(()=>toast('Audio preview unavailable.',true));}return;}
 if(cmd==='export'){const data=JSON.stringify(store,null,2),name='random-workout-sessions-'+new Date().toISOString().slice(0,10)+'.json';if(window.AndroidSpeech&&typeof AndroidSpeech.exportConfiguration==='function'){AndroidSpeech.exportConfiguration(data,name);toast('Choose where to save your JSON backup.')}else{const url=URL.createObjectURL(new Blob([data],{type:'application/json'})),link=document.createElement('a');link.href=url;link.download=name;link.click();setTimeout(()=>URL.revokeObjectURL(url),1000);}return;}
 if(cmd==='import'){$('#importFile').click();return;}
 }
 $('#app').addEventListener('click',e=>{const node=e.target.closest('button[data-do]');if(node&&!node.disabled)onButton(node)});
 $('#app').addEventListener('input',e=>{if(e.target.matches('[data-field]'))onField(e.target)});
 $('#app').addEventListener('change',e=>{if(e.target.matches('[data-field]')){onField(e.target);render();}});
 $('#importFile').addEventListener('change',async e=>{const file=e.target.files?.[0];e.target.value='';if(!file)return;
  try{if(file.size>5*1024*1024)throw new Error('Backup exceeds the 5 MB limit.');const parsed=JSON.parse(await file.text());const imported=M.normalizeImport(parsed);
   const warnings=M.validateStore(imported);const question='Import '+imported.sessions.length+' session(s)? This will REPLACE all sessions currently saved in this app.'+(warnings.length?'\n\nNote: '+warnings.length+' configuration warning(s) will need attention.':'');
   if(!confirm(question))return;store=imported;save();go('home');toast('Backup imported successfully.');}
  catch(err){toast('Import failed: '+err.message,true)}
 });
 window.onNativeBackupEvent=(state,detail)=>toast(detail,state!=='ok');
 render();
})();
